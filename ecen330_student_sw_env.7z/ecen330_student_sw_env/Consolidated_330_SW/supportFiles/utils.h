/*
 * utils.h
 *
 *  Created on: Jul 18, 2014
 *      Author: hutch
 */

#ifndef UTILS_H_
#define UTILS_H_

void utils_msDelay(long ms);

#endif /* UTILS_H_ */
